import Link from 'next/link';
import { photoCredits } from '@/lib/photos';

// The black about panel with a big top radius, and a cobalt strip underneath that repeats one line of credit.
const LINKS: [string, string][] = [['Upcoming events', '/#events'], ['Create an account', '/register'], ['My tickets', '/me'], ['Organizer portal', '/organizer/login'], ['Volunteer gate scanner', '/dashboard']];

export default function Footer() {
  const credits = photoCredits();
  return (
    <footer className="mt-24">
      <div className="panel-round bg-[#111111] px-4 pb-14 pt-16 text-[#f4efe9] sm:px-6">
        <div className="mx-auto grid max-w-6xl gap-10 md:grid-cols-[1fr_1fr]">
          <div>
            <p className="display text-6xl">SeatLock</p>
            <p className="mono mt-4 max-w-sm">Event registration for college societies. Every seat is handed out once, even when the whole campus clicks at the same second.</p>
          </div>
          <ul className="mono space-y-2.5 text-lg">
            {LINKS.map(([label, href]) => <li key={label}><Link className="underline-offset-4 hover:underline" href={href}>{label}</Link></li>)}
          </ul>
        </div>
        {credits.length > 0 && <p className="mono mx-auto mt-10 max-w-6xl text-xs opacity-70">Photos: {credits.join(' · ')}</p>}
      </div>
      <p className="mono bg-cobalt px-4 py-3 text-center text-sm">© {new Date().getFullYear()} SeatLock · Free to register, one seat per person · Times are shown in IST</p>
    </footer>
  );
}
