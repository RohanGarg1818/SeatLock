import Link from 'next/link';
import { dayNum, fmtTime, monthShort } from '@/lib/format';
import type { PublicEvent } from '@/lib/types';
import Snapshot from '@/components/ui/Snapshot';
import { kindOf, photoSrc } from '@/lib/photos';

const weekday = (iso: string) => new Date(iso).toLocaleDateString('en-IN', { weekday: 'short', timeZone: 'Asia/Kolkata' });

// The first screen: a masthead and a poster-size statement on the left; on the right a taped snapshot of the next real event
// with its boarding-pass ticket and a round stamp stuck over it. With no open event it says so instead of inventing one.
export default function TicketHero({ event, open, seats }: { event: PublicEvent | null; open: number; seats: number }) {
  const kind = event ? kindOf(event.title) : 'talk';
  const src = event ? (event.banner_url ?? photoSrc(kind)) : photoSrc(kind);
  return (
    <section className="grid items-center gap-12 pb-8 pt-2 lg:grid-cols-[1.05fr_1fr] lg:gap-10 lg:pt-6" aria-labelledby="hero-h">
      <div>
        <p className="mono inline-block border-2 border-ink-line px-3 py-1 text-sm font-bold">SEATLOCK / EVENT INDEX / {new Date().getFullYear()}</p>
        <h1 id="hero-h" className="display mt-5 text-[5.2rem] leading-[0.88] sm:text-[8rem] lg:text-[9.5rem]">Hold<br />your<br />seat.</h1>
        <p className="mt-6 max-w-[44ch] text-lg">Every talk, workshop and hackathon your societies run, in one place. Hold a seat while you register, get a QR ticket, walk in. A seat is never given to two people.</p>
        <div className="mt-7 flex flex-wrap items-center gap-3">
          <Link href="/#events" className="btn btn-primary btn-lg">Browse events</Link>
          <Link href="/organizer/signup" className="btn btn-lg">Run an event</Link>
        </div>
        {open > 0 && (
          <p className="mono mt-7 flex flex-wrap gap-x-8 gap-y-1 text-sm">
            <span><b className="display num text-3xl">{open}</b> event{open === 1 ? '' : 's'} open</span>
            <span><b className="display num text-3xl">{seats}</b> seats free right now</span>
          </p>
        )}
      </div>

      <div className="relative mx-auto w-full max-w-md pb-16 pt-6 lg:max-w-none lg:pb-20 lg:pl-10">
        <div className="ml-auto w-[78%] max-w-sm"><Snapshot src={src} kind={kind} rotate={6} priority className="!p-2 !pb-8" /></div>
        <div className="pass absolute bottom-0 left-0 w-[72%] max-w-xs -rotate-3 p-5 sm:p-6 ">
          <p className="mono text-xs font-bold uppercase">{event ? 'Boarding: next up' : 'Boarding soon'}</p>
          {event ? (
            <>
              <h2 className="display mt-1 line-clamp-2 text-2xl sm:text-3xl">{event.title}</h2>
              <p className="mono num mt-2 text-sm">{weekday(event.starts_at)} {dayNum(event.starts_at)} {monthShort(event.starts_at)}, {fmtTime(event.starts_at)}</p>
              <p className="mono text-sm">{event.venue}</p>
              <Link href={`/e/${event.slug}`} className="btn btn-primary btn-sm mt-4 w-full">Hold a seat</Link>
            </>
          ) : (
            <>
              <h2 className="display mt-1 text-2xl">No event is open</h2>
              <Link href="/organizer/signup" className="btn btn-primary btn-sm mt-4 w-full">Publish an event</Link>
            </>
          )}
        </div>
        {event && event.registration_state === 'OPEN' && (
          <span className="stamp absolute right-0 top-0 bg-yellow text-[#111111] lg:right-2" style={{ ['--r' as string]: '14deg' }} aria-label={`${event.seats_left} seats left`}>
            <span><span className="num block text-3xl">{event.seats_left}</span><span className="block text-sm">seats left</span></span>
          </span>
        )}
      </div>
    </section>
  );
}
