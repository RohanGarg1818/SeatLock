import Link from 'next/link';
import { publicFetch } from '@/lib/server';
import type { PublicEvent } from '@/lib/types';
import EventExplorer from '@/components/events/EventExplorer';
import TicketHero from '@/components/home/TicketHero';
import Ticker from '@/components/home/Ticker';
import Proof from '@/components/home/Proof';
import { photoMap } from '@/lib/photos';
import Faq from '@/components/ui/Faq';
import { HoldTimer, Queue, SeatPlan, TicketArt } from '@/components/ui/Pictures';

// Each sheet slides up over the one before it. Fills come from the page's palette, ink chosen per sheet.
const SHEETS = [
  { name: 'Never oversold', text: 'Checking and taking a seat happen in one database step. Two people can never get the last seat, however many click at once.', bg: 'bg-pink', rot: '-1.2deg', art: <SeatPlan className="w-full" /> },
  { name: 'Timed holds', text: 'A seat is held while you fill in the form. If you walk away, the timer runs out and the seat goes back to the pool.', bg: 'bg-yellow', rot: '1deg', art: <HoldTimer className="mx-auto w-full max-w-xs" /> },
  { name: 'A waitlist that runs itself', text: 'When a seat frees up, the first person in line is given it, in order, with nobody refreshing the page.', bg: 'bg-sage', rot: '1.2deg', art: <Queue className="w-full max-w-lg" /> },
  { name: 'Signed QR tickets', text: 'Every ticket carries a signature. Edited, copied or forged codes are rejected at the gate, and a real one works exactly once.', bg: 'bg-orange', rot: '-1deg', art: <TicketArt className="w-full max-w-md" /> },
];

// The legend under the hero: the stickers used all over the site, defined once.
const LEGEND = [
  { t: 'Open', s: 'seats free', c: 'bg-sage', r: '-4deg' },
  { t: 'Held', s: '5 min timer', c: 'bg-yellow', r: '3deg' },
  { t: 'Waitlist', s: 'sold out? queue', c: 'bg-pink', r: '-2deg' },
  { t: 'QR ticket', s: 'signed, one use', c: 'bg-orange', r: '4deg' },
  { t: 'Checked in', s: 'scanned at the gate', c: 'bg-cobalt', r: '-3deg' },
];

const SLIP: { when: string; rows: [string, string][] }[] = [
  { when: 'Before the event', rows: [['Find an event and open it', '1 min'], ['Hold a seat', '5:00 timer'], ['Answer the registration questions', '1 min'], ['Confirm, and the QR ticket appears', 'instant']] },
  { when: 'On the day', rows: [['Show the QR ticket at the gate', '2 sec'], ['A volunteer scans it on a phone', '2 sec']] },
];

export default async function Home() {
  const { status, data } = await publicFetch<{ events: PublicEvent[] }>('/public/events', 20);
  const events = data?.events ?? [];
  const ok = status === 200;
  const soonest = events.filter((e) => e.registration_state === 'OPEN').sort((a, b) => a.starts_at.localeCompare(b.starts_at))[0] ?? null;

  const openEvents = events.filter((e) => e.registration_state === 'OPEN');
  const seatsFree = openEvents.reduce((n, e) => n + e.seats_left, 0);

  return (
    <>
      <TicketHero event={soonest} open={openEvents.length} seats={seatsFree} />
      <ul className="mt-6 flex flex-wrap justify-center gap-x-6 gap-y-5 pb-10" aria-label="What the stickers mean">
        {LEGEND.map((l) => <li key={l.t}><span className={`sticker ${l.c}`} style={{ ['--r' as string]: l.r }}>{l.t}<small>{l.s}</small></span></li>)}
      </ul>
      <Ticker events={events} />

      {/* events */}
      <section id="events" className="scroll-mt-24 pt-16 sm:pt-20" aria-labelledby="events-h">
        <h2 id="events-h" className="display reveal text-6xl sm:text-8xl">The index</h2>
        <p className="mono reveal mt-4 max-w-[60ch]">Every upcoming event, ranked by what matters: how many seats are left. Pick one, hold your seat, done.</p>
        <div className="mt-10">
          {!ok && (
            <div role="alert" className="card flex flex-col items-start gap-3 p-6 sm:flex-row sm:items-center sm:justify-between">
              <div>
                <p className="display text-3xl">Events did not load</p>
                <p className="mt-1 text-muted">The server may be waking up after a quiet spell. Try again in a few seconds.</p>
                {process.env.NODE_ENV !== 'production' && <p className="hint mt-2">Developer note: the website could not reach the backend. Start it with <code>npm run dev</code> (from the project root) and check http://localhost:4000/health.</p>}
              </div>
              <Link href="/" className="btn btn-primary shrink-0">Try again</Link>
            </div>
          )}
          {ok && events.length === 0 && (
            <div className="card px-6 py-14">
              <p className="display text-4xl">No events yet</p>
              <p className="mt-2 max-w-md text-muted">Nothing is open for registration right now. If you run a society, you can publish the first event.</p>
              <Link href="/organizer/signup" className="btn btn-primary mt-6">Publish an event</Link>
            </div>
          )}
          {ok && events.length > 0 && <EventExplorer events={events} photos={photoMap()} />}
        </div>
      </section>

      {/* features: four colour panels, side by side */}
      <section id="features" className="scroll-mt-24 pt-20 sm:pt-28" aria-labelledby="feat-h">
        <h2 id="feat-h" className="display reveal text-6xl sm:text-8xl">What keeps it fair</h2>
        <div className="mt-10 grid gap-4 sm:grid-cols-2">
          {SHEETS.map((s) => (
            <article key={s.name} className={`reveal sticker-card flex flex-col justify-between gap-6 p-6 sm:p-8 ${s.bg}`} style={{ ['--r' as string]: s.rot }}>
              <div className="flex h-44 items-center justify-center [&>svg]:!h-full [&>svg]:!w-auto [&>svg]:!max-w-full">{s.art}</div>
              <div>
                <h3 className="display text-4xl">{s.name}</h3>
                <p className="mono mt-2 max-w-[46ch]">{s.text}</p>
              </div>
            </article>
          ))}
        </div>
      </section>

      <Proof />

      {/* how it works: an itinerary on a slip */}
      <section id="how" className="scroll-mt-24 pt-20 sm:pt-28" aria-labelledby="how-h">
        <div className="grid items-start gap-10 lg:grid-cols-[1fr_30rem] lg:gap-20">
          <div>
            <h2 id="how-h" className="display reveal text-6xl sm:text-8xl">From click to front row</h2>
            <p className="reveal mt-5 max-w-[34ch] text-lg">The whole journey takes about eight minutes, and most of it is you reading the registration form.</p>
          </div>
          <div className="slip reveal px-6 pt-6">
            {SLIP.map((g) => (
              <div key={g.when} className="mt-6 first:mt-0">
                <h3 className="text-xl font-semibold">{g.when}</h3>
                <ol className="mt-2 space-y-2">
                  {g.rows.map(([what, t]) => (
                    <li key={what} className="flex items-end gap-2"><span>{what}</span><span className="leader" aria-hidden /><span className="num">{t}</span></li>
                  ))}
                </ol>
              </div>
            ))}
            <p className="mono -mx-6 mt-6 flex items-center justify-between bg-[#111111] px-6 py-3 text-[#f4efe9]"><span>One QR ticket, one entry</span><span className="num">about 8 min</span></p>
          </div>
        </div>
      </section>

      {/* organizers: a clip-out coupon on the black about panel */}
      <section className="bleed panel-round mt-24 overflow-hidden bg-[#111111] sm:mt-32" aria-labelledby="org-h">
        <div className="mx-auto grid max-w-6xl items-center gap-10 px-4 py-16 sm:px-6 sm:py-24 lg:grid-cols-[1fr_1.2fr]">
          <div className="text-[#f4efe9]">
            <p className="mono text-sm font-bold">FOR SOCIETIES</p>
            <p className="mono reveal mt-4 max-w-[40ch]">Publish an event in a few minutes, share one link, and watch the seats fill. Holds, the waitlist, tickets and check-in are handled for you. Add a poster and it becomes the cover of your entry in the index.</p>
          </div>
          <div className="reveal -rotate-1 border-2 border-[#111111] bg-pink p-8 text-[#111111] sm:p-12" style={{ borderRadius: 24, boxShadow: '6px 6px 0 #f4efe9' }}>
            <h2 id="org-h" className="display text-5xl sm:text-6xl">Run your society&apos;s next event</h2>
            <p className="mono mt-3 max-w-xs">Free to start. Your own login and your own dashboard.</p>
            <Link href="/organizer/signup" className="btn btn-primary btn-lg mt-6 w-full">Open the organizer portal</Link>
            <Link href="/organizer/login" className="mono mt-4 inline-block underline underline-offset-4">I already have an organizer account</Link>
          </div>
        </div>
      </section>

      {/* faq */}
      <section id="faq" className="scroll-mt-24 pt-24 sm:pt-32" aria-labelledby="faq-h">
        <h2 id="faq-h" className="display reveal mb-10 text-6xl sm:text-8xl">Good to know</h2>
        <Faq />
      </section>
    </>
  );
}
