import Link from 'next/link';
import type { PublicEvent } from '@/lib/types';
import { StateTag } from '@/components/ui/StateTag';
import Snapshot from '@/components/ui/Snapshot';
import { kindOf, type Kind } from '@/lib/kind';
import { dayNum, fmtTime, monthShort, modeLabel } from '@/lib/format';

const TAG: Record<string, string> = { OPEN: 'bg-sage', NOT_OPEN: 'bg-yellow', SOLD_OUT: 'bg-orange', CLOSED: 'bg-surface-2', CANCELLED: 'bg-surface-2' };

// One event = one dossier entry: a taped snapshot (the organizer's poster, else a real photo of this kind of event), the
// name and where, a field note, the sticker tags, and the live number of free seats as a circled score.
export default function EventCard({ e, index = 0, photos = {} }: { e: PublicEvent; index?: number; photos?: Partial<Record<Kind, string>> }) {
  const kind = kindOf(e.title);
  const src = e.banner_url ?? photos[kind] ?? null;
  const open = e.registration_state === 'OPEN';
  const score = open ? e.seats_left : e.registration_state === 'SOLD_OUT' ? 0 : null;
  return (
    <Link href={`/e/${e.slug}`} className="dossier-row group">
      <div className="w-40 md:w-full"><Snapshot src={src} kind={kind} rotate={index % 2 ? 3 : -3} /></div>
      <div className="min-w-0">
        <p className="mono text-sm text-muted">No. {String(index + 1).padStart(2, '0')} · {dayNum(e.starts_at)} {monthShort(e.starts_at)}, {fmtTime(e.starts_at)}</p>
        <h3 className="display mt-1 text-4xl group-hover:underline group-hover:decoration-4 group-hover:underline-offset-4 sm:text-5xl" title={e.title}>{e.title}</h3>
        <p className="mono mt-2 font-bold">{e.venue} <span className="font-normal text-muted">({modeLabel[e.mode]})</span>{e.host ? <span className="font-normal text-muted"> · {e.host}</span> : null}</p>
        {e.tagline && <p className="mono mt-2 max-w-[52ch] text-[0.95rem]">{e.tagline}</p>}
        <p className="mt-3 flex flex-wrap items-center gap-2"><StateTag state={e.registration_state} />{open && e.seats_left <= Math.max(3, Math.ceil(e.capacity * 0.1)) && <span className="sticker sticker-sm bg-orange">Almost gone</span>}{e.allowed_email_domains?.length ? <span className="sticker sticker-sm bg-yellow">College email</span> : null}</p>
      </div>
      <div className="hidden md:block">
        <p className="mono text-sm font-bold">How it works</p>
        <ul className="mono mt-1 list-disc pl-4 text-sm leading-snug"><li>Hold a seat while you register</li><li>Get a QR ticket</li><li>Waitlist if it fills</li></ul>
      </div>
      <div className={`flex items-center gap-3 md:block ${open ? '' : 'text-muted'}`}>
        <p className="mono text-sm font-bold md:mb-1">{open ? 'Seats left' : e.registration_state === 'SOLD_OUT' ? 'Waitlist' : 'Status'}</p>
        {score !== null ? <span className="circle-score num" aria-label={`${score} of ${e.capacity} seats free`}>{score}</span> : <span className={`sticker sticker-sm ${TAG[e.registration_state]}`}>{e.registration_state === 'NOT_OPEN' ? `Opens ${dayNum(e.registration_opens_at)} ${monthShort(e.registration_opens_at)}` : 'Closed'}</span>}
      </div>
    </Link>
  );
}
