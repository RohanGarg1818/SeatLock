// Which kind of event a title describes (client-safe; the server side lives in photos.ts).
export type Kind = 'hackathon' | 'workshop' | 'mic' | 'robotics' | 'design' | 'ml' | 'talk';
export const KINDS: Kind[] = ['hackathon', 'workshop', 'mic', 'robotics', 'design', 'ml', 'talk'];

export function kindOf(title: string): Kind {
  const t = title.toLowerCase();
  if (/hack|ctf|code-?a-?thon/.test(t)) return 'hackathon';
  if (/robot|drone|iot|arduino/.test(t)) return 'robotics';
  if (/mic|music|band|night|dance|concert|fest/.test(t)) return 'mic';
  if (/design|sprint|ui|ux|figma/.test(t)) return 'design';
  if (/\bml\b|machine|learning|data|ai\b|study jam/.test(t)) return 'ml';
  if (/rust|workshop|bootcamp|intro|python|web|git/.test(t)) return 'workshop';
  return 'talk';
}

